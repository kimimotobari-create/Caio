package com.example.keuangandriver

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

const val JENIS_PENDAPATAN = "PENDAPATAN"
const val JENIS_PENGELUARAN = "PENGELUARAN"

val KATEGORI_PENDAPATAN = listOf("Grab Bike", "Gojek")
val KATEGORI_PENGELUARAN = listOf("BBM", "Parkir", "Tol", "Makan/Minum", "Servis/Ganti Oli", "Cicilan", "Pulsa/Kuota", "Cuci Kendaraan", "Lainnya")

@Entity(tableName = "transaksi")
data class Transaksi(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tanggal: Long, // epoch day
    val jenis: String,
    val kategori: String,
    val jumlah: Long,
    val catatan: String = ""
)

@Dao
interface TransaksiDao {
    @Query("SELECT * FROM transaksi WHERE tanggal BETWEEN :dari AND :sampai ORDER BY tanggal DESC, id DESC")
    fun observe(dari: Long, sampai: Long): Flow<List<Transaksi>>

    @Insert
    suspend fun insert(t: Transaksi)

    @Delete
    suspend fun delete(t: Transaksi)
}

@Database(entities = [Transaksi::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): TransaksiDao

    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "keuangan.db")
                .build().also { instance = it }
        }
    }
}
