package com.example.keuangandriver

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.CardGiftcard
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.NumberFormat
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle as HariStyle
import java.util.Locale
import android.net.Uri
import android.widget.VideoView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.widget.Toast
import kotlin.random.Random

private val Bg = Color(0xFF101827)
private val Panel = Color(0xFF1B2A40)
private val Ink = Color(0xFFF1F6FF)
private val Muted = Color(0xFFA8B8CE)
private val Line = Color(0xFF344861)
private val Gold = Color(0xFF60A5FA) // biru utama
private val Masuk = Color(0xFF4ADEB5) // hijau toska
private val Keluar = Color(0xFFFF8A80) // coral
private val Keluarga = Color(0xFFFFC857) // aksen hangat
private val Semangat = Color(0xFFB69CFF) // ungu

private val fotoBayi = listOf(
    R.drawable.bayi_1, R.drawable.bayi_2, R.drawable.bayi_3, R.drawable.bayi_4, R.drawable.bayi_5
)

private val rupiah: NumberFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
    maximumFractionDigits = 0
}
private fun Long.rp(): String = rupiah.format(this)
private val tglPendek = DateTimeFormatter.ofPattern("d MMM yyyy", Locale("id", "ID"))
private val tglPanjang = DateTimeFormatter.ofPattern("EEE, d MMM", Locale("id", "ID"))

private fun ambilNominalDariOcr(teks: String): Long? {
    val pola = Regex("(?i)(?:rp\\s*)?([0-9][0-9.,]{2,})")
    val baris = teks.lines().map { line ->
        val nilai = pola.findAll(line).mapNotNull { it.groupValues[1].filter(Char::isDigit).toLongOrNull() }
            .filter { it in 1_000L..500_000_000L }.toList()
        val lower = line.lowercase(Locale("id", "ID"))
        val skor = (if (lower.contains("rp")) 4 else 0) +
            (if (lower.contains("pendapatan") || lower.contains("penghasilan")) 6 else 0) +
            (if (lower.contains("total") || lower.contains("insentif")) 2 else 0)
        Triple(skor, nilai, line)
    }.filter { it.second.isNotEmpty() }
    val prioritas = baris.filter { it.first > 0 }
    val sumber = if (prioritas.isNotEmpty()) prioritas else baris
    return sumber.maxWithOrNull(compareBy<Triple<Int, List<Long>, String>> { it.first }.thenBy { it.second.maxOrNull() ?: 0L })
        ?.second?.maxOrNull()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Gold, onPrimary = Bg,
                    background = Bg, onBackground = Ink,
                    surface = Panel, onSurface = Ink,
                    onSurfaceVariant = Muted, outline = Line
                )
            ) {
                HomeScreen(quickType = intent.getStringExtra("quick_type"))
            }
        }
    }
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }
}

@Composable
fun HomeScreen(vm: MainViewModel = viewModel(), quickType: String? = null) {
    val list by vm.transaksi.collectAsState()
    val grafik by vm.grafik.collectAsState()
    val periode by vm.periode.collectAsState()
    var showSheet by remember { mutableStateOf(quickType == JENIS_PENDAPATAN || quickType == JENIS_PENGELUARAN) }
    var ocrAmount by remember { mutableStateOf("") }
    var tipeBaru by remember { mutableStateOf(quickType ?: JENIS_PENDAPATAN) }
    val context = LocalContext.current
    val ocrLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                val image = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result ->
                        val amount = ambilNominalDariOcr(result.text)
                        if (amount != null) { ocrAmount = amount.toString(); tipeBaru = JENIS_PENDAPATAN; showSheet = true; Toast.makeText(context, "Nominal terdeteksi: ${amount.rp()}", Toast.LENGTH_LONG).show() }
                        else Toast.makeText(context, "Nominal tidak ditemukan. Coba screenshot yang lebih jelas.", Toast.LENGTH_LONG).show()
                    }.addOnFailureListener { Toast.makeText(context, "OCR gagal membaca gambar", Toast.LENGTH_SHORT).show() }
            } catch (_: Exception) { Toast.makeText(context, "Gambar tidak dapat dibaca", Toast.LENGTH_SHORT).show() }
        }
    }
    var transaksiEdit by remember { mutableStateOf<Transaksi?>(null) }
    var fotoIdx by remember { mutableStateOf(LocalDate.now().dayOfYear % fotoBayi.size) }
    var isiIdx by remember { mutableStateOf(Random.nextInt(ISI_HARIAN.size)) }

    val pendapatan = list.filter { it.jenis == JENIS_PENDAPATAN }.sumOf { it.jumlah }
    val pengeluaran = list.filter { it.jenis == JENIS_PENGELUARAN }.sumOf { it.jumlah }
    val bersih = pendapatan - pengeluaran

    val jam = LocalTime.now().hour
    val sapa = when {
        jam < 11 -> "Selamat pagi"
        jam < 15 -> "Selamat siang"
        jam < 18 -> "Selamat sore"
        else -> "Selamat malam"
    }
    val isi = ISI_HARIAN[isiIdx]
    val sisi = Modifier.fillMaxWidth().padding(horizontal = 24.dp)

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            Box(Modifier.fillMaxWidth().background(Bg).navigationBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp)) {
                Button(
                    onClick = { transaksiEdit = null; tipeBaru = JENIS_PENDAPATAN; showSheet = true },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Bg)
                ) { Text("+  Catat", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
            }
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding)) {
            // Kutipan / fakta unik + ikon gift
            item {
                Row(sisi.padding(top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(42.dp).clip(CircleShape).border(1.dp, Line, CircleShape)
                            .clickable { isiIdx = (isiIdx + 1 + Random.nextInt(ISI_HARIAN.size - 1)) % ISI_HARIAN.size },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Outlined.CardGiftcard, contentDescription = "Ganti", tint = Gold, modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(isi.jenis.uppercase(), fontSize = 10.sp, color = Semangat, letterSpacing = 1.5.sp)
                        Text(isi.teks, fontSize = 13.sp, color = Ink, maxLines = 3)
                    }
                }
            }
            // Foto keluarga sebagai latar
            item {
                Box(Modifier.fillMaxWidth().height(250.dp)) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { context ->
                            VideoView(context).apply {
                                setVideoURI(Uri.parse("android.resource://${context.packageName}/${R.raw.bg_landscape}"))
                                setOnPreparedListener { player ->
                                    player.isLooping = true
                                    player.setVolume(0f, 0f)
                                    start()
                                }
                            }
                        },
                        update = { if (!it.isPlaying) it.start() }
                    )
                    Box(Modifier.fillMaxSize().background(
                        Brush.verticalGradient(0f to Color(0x66000000), 0.48f to Color(0x22000000), 1f to Bg)
                    ))
                    Text(
                        "Sangu Kapiii", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Gold,
                        modifier = Modifier.padding(start = 24.dp, top = 16.dp)
                    )
                    Row(
                        Modifier.align(Alignment.BottomStart).padding(start = 24.dp, bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(fotoBayi[fotoIdx]),
                            contentDescription = "Foto keluarga",
                            modifier = Modifier.size(54.dp).clip(CircleShape).border(1.5.dp, Gold, CircleShape)
                                .clickable { fotoIdx = (fotoIdx + 1) % fotoBayi.size },
                            contentScale = ContentScale.Crop
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(sapa, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(LocalDate.now().format(tglPanjang), fontSize = 12.sp, color = Color.White)
                            Text("Semangat mencari rezeki untuk keluarga", fontSize = 11.sp, color = Keluarga)
                        }
                    }
                }
            }
            item {
                Column(sisi) {
                    Spacer(Modifier.height(20.dp))
                    PeriodeTabs(periode, vm.mingguOffset.value) { vm.periode.value = it }
                    if (periode == Periode.MINGGU_INI) {
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { vm.mingguOffset.value = vm.mingguOffset.value - 1 }) { Text("‹ Minggu sebelumnya", color = Gold) }
                            TextButton(onClick = { vm.mingguOffset.value = (vm.mingguOffset.value + 1).coerceAtMost(0) }) { Text("Minggu berikutnya ›", color = Gold) }
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        RingkasWidget("＋", "PENDAPATAN", pendapatan.rp(), Masuk, Modifier.weight(1f)) {
                            transaksiEdit = null; tipeBaru = JENIS_PENDAPATAN; showSheet = true
                        }
                        RingkasWidget("−", "PENGELUARAN", pengeluaran.rp(), Keluar, Modifier.weight(1f)) {
                            transaksiEdit = null; tipeBaru = JENIS_PENGELUARAN; showSheet = true
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    RingkasWidget("=", "SALDO BERSIH", bersih.rp(), if (bersih < 0) Keluar else Gold, Modifier.fillMaxWidth()) {}
                    Spacer(Modifier.height(24.dp))
                    Text("Penghasilan bersih", fontSize = 13.sp, color = Muted)
                    Text(
                        bersih.rp(), fontSize = 40.sp, fontWeight = FontWeight.Light,
                        color = if (bersih < 0) Keluar else Ink
                    )
                    Spacer(Modifier.height(20.dp))
                    Row(Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text("Pendapatan", fontSize = 12.sp, color = Muted)
                            Text(pendapatan.rp(), fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Masuk)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Pengeluaran", fontSize = 12.sp, color = Muted)
                            Text(pengeluaran.rp(), fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Keluar)
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    HorizontalDivider(color = Line)
                    Spacer(Modifier.height(20.dp))
                    GrafikMingguan(grafik)
                    if (periode == Periode.RINGKASAN) {
                        Spacer(Modifier.height(22.dp))
                        Text("RINGKASAN KEUANGAN • ${LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale("id", "ID")))}".uppercase(Locale("id", "ID")), color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Total pemasukan: ${pendapatan.rp()}", color = Masuk, fontSize = 15.sp)
                        Text("Total pengeluaran: ${pengeluaran.rp()}", color = Keluar, fontSize = 15.sp)
                        Text("Sisa bersih: ${bersih.rp()}", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Jumlah transaksi: ${list.size}", color = Muted, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    TextButton(onClick = { tipeBaru = JENIS_PENDAPATAN; ocrAmount = ""; ocrLauncher.launch("image/*") }) {
                        Text("▧  Baca screenshot Grab (OCR)", color = Gold, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item { Column(sisi) { RincianPengeluaran(list.filter { it.jenis == JENIS_PENGELUARAN }) } }
            item {
                Column(sisi) {
                    Spacer(Modifier.height(24.dp))
                    Text("RIWAYAT", fontSize = 12.sp, color = Muted, letterSpacing = 1.sp)
                }
            }
            if (list.isEmpty()) {
                item {
                    Column(
                        sisi.padding(vertical = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(fotoBayi[fotoIdx]),
                            contentDescription = null,
                            modifier = Modifier.size(140.dp).clip(CircleShape).border(1.5.dp, Gold, CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(Modifier.height(16.dp))
                        Text("Belum ada catatan", color = Muted, textAlign = TextAlign.Center)
                        Text("Semangat narik hari ini!", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                }
            }
            items(list, key = { it.id }) { t ->
                Column(sisi) {
                    TransaksiRow(t, onEdit = { transaksiEdit = t; tipeBaru = t.jenis; showSheet = true }, onDelete = { vm.hapus(t) })
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }

    if (showSheet) {
        CatatSheet(existing = transaksiEdit, initialType = tipeBaru, ocrAmount = ocrAmount, onPilihScreenshot = { ocrLauncher.launch("image/*") }, onDismiss = { showSheet = false; transaksiEdit = null; ocrAmount = "" }, onSimpan = {
            if (transaksiEdit == null) vm.tambah(it) else vm.edit(it)
            showSheet = false; transaksiEdit = null; ocrAmount = ""
        })
    }
}

@Composable
fun PeriodeTabs(selected: Periode, mingguOffset: Int, onSelect: (Periode) -> Unit) {
    val hariIni = LocalDate.now()
    val awalMinggu = hariIni.with(java.time.DayOfWeek.MONDAY).plusWeeks(mingguOffset.toLong())
    val akhirMinggu = awalMinggu.plusDays(6)
    val rentangBulan = "1–${hariIni.dayOfMonth} ${hariIni.format(DateTimeFormatter.ofPattern("MMM", Locale("id", "ID")))}"
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        Periode.values().forEach { p ->
            val aktif = p == selected
            val tanggalTab = when (p) {
                Periode.HARI_INI -> hariIni.format(DateTimeFormatter.ofPattern("d MMM", Locale("id", "ID")))
                Periode.MINGGU_INI -> "${awalMinggu.format(DateTimeFormatter.ofPattern("d MMM", Locale("id", "ID")))} – ${akhirMinggu.format(tglPendek)}"
                Periode.BULAN_INI, Periode.RINGKASAN -> rentangBulan
            }
            Column(Modifier.clickable { onSelect(p) }) {
                Text(p.label, fontSize = 14.sp,
                    fontWeight = if (aktif) FontWeight.Bold else FontWeight.Normal,
                    color = if (aktif) Ink else Muted)
                Spacer(Modifier.height(3.dp))
                Text(tanggalTab, fontSize = 10.sp, color = if (aktif) Gold else Muted, maxLines = 1, letterSpacing = 0.1.sp)
                Spacer(Modifier.height(4.dp))
                Box(Modifier.height(2.dp).width(20.dp).background(if (aktif) Gold else Color.Transparent))
            }
        }
    }
}

@Composable
fun GrafikMingguan(data: List<Transaksi>) {
    val hari = (6 downTo 0).map { LocalDate.now().minusDays(it.toLong()) }
    val masuk = hari.map { d -> data.filter { it.tanggal == d.toEpochDay() && it.jenis == JENIS_PENDAPATAN }.sumOf { it.jumlah } }
    val keluar = hari.map { d -> data.filter { it.tanggal == d.toEpochDay() && it.jenis == JENIS_PENGELUARAN }.sumOf { it.jumlah } }
    val maks = maxOf(masuk.maxOrNull() ?: 0L, keluar.maxOrNull() ?: 0L, 1L).toFloat()

    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("7 HARI TERAKHIR", fontSize = 12.sp, color = Muted, letterSpacing = 1.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(Gold))
                Spacer(Modifier.width(4.dp))
                Text("Pendapatan", fontSize = 11.sp, color = Ink)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.size(8.dp).clip(CircleShape).background(Keluar))
                Spacer(Modifier.width(4.dp))
                Text("Pengeluaran", fontSize = 11.sp, color = Ink)
            }
        }
        Spacer(Modifier.height(12.dp))
        Canvas(Modifier.fillMaxWidth().height(130.dp)) {
            val slot = size.width / 7f
            val bw = slot * 0.24f
            val gap = 3f
            drawLine(color = Line, start = Offset(0f, size.height), end = Offset(size.width, size.height), strokeWidth = 2f)
            for (i in 0 until 7) {
                val cx = slot * i + slot / 2f
                if (masuk[i] > 0) {
                    val h = (size.height * (masuk[i].toFloat() / maks)).coerceAtLeast(6f)
                    drawRoundRect(
                        color = Gold,
                        topLeft = Offset(cx - bw - gap / 2f, size.height - h),
                        size = Size(bw, h),
                        cornerRadius = CornerRadius(6f, 6f)
                    )
                }
                if (keluar[i] > 0) {
                    val h = (size.height * (keluar[i].toFloat() / maks)).coerceAtLeast(6f)
                    drawRoundRect(
                        color = Keluar,
                        topLeft = Offset(cx + gap / 2f, size.height - h),
                        size = Size(bw, h),
                        cornerRadius = CornerRadius(6f, 6f)
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth()) {
            hari.forEachIndexed { i, d ->
                Text(
                    d.dayOfWeek.getDisplayName(HariStyle.SHORT, Locale("id", "ID")),
                    modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 11.sp,
                    fontWeight = if (i == 6) FontWeight.Bold else FontWeight.Normal,
                    color = if (i == 6) Ink else Muted
                )
            }
        }
    }
}

@Composable
fun RincianPengeluaran(pengeluaran: List<Transaksi>) {
    if (pengeluaran.isEmpty()) return
    val total = pengeluaran.sumOf { it.jumlah }.coerceAtLeast(1)
    val per = pengeluaran.groupBy { it.kategori }
        .mapValues { e -> e.value.sumOf { it.jumlah } }
        .toList().sortedByDescending { it.second }
    Column(Modifier.padding(top = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PENGELUARAN", fontSize = 12.sp, color = Muted, letterSpacing = 1.sp)
        per.forEach { (k, v) ->
            val frac = (v.toFloat() / total.toFloat()).coerceIn(0.02f, 1f)
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(k, fontSize = 14.sp, color = Ink)
                    Text(v.rp(), fontSize = 14.sp, color = Muted)
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth().height(3.dp).background(Line, RoundedCornerShape(2.dp))) {
                    Box(Modifier.fillMaxWidth(frac).height(3.dp).background(Gold, RoundedCornerShape(2.dp)))
                }
            }
        }
    }
}

@Composable
fun TransaksiRow(t: Transaksi, onEdit: () -> Unit, onDelete: () -> Unit) {
    val masuk = t.jenis == JENIS_PENDAPATAN
    Column {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.kategori, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Ink)
                Text(
                    LocalDate.ofEpochDay(t.tanggal).format(tglPendek) +
                        if (t.catatan.isNotBlank()) "  ·  ${t.catatan}" else "",
                    fontSize = 12.sp, color = Muted
                )
            }
            Text(
                (if (masuk) "+" else "−") + t.jumlah.rp(),
                fontSize = 15.sp, fontWeight = FontWeight.Medium, color = if (masuk) Masuk else Keluar
            )
            TextButton(onClick = onEdit) { Text("Edit", color = Gold, fontSize = 12.sp) }
            IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Hapus", tint = Muted, modifier = Modifier.size(16.dp))
            }
        }
        HorizontalDivider(color = Line)
    }
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Gold else Color.Transparent)
            .border(1.dp, if (selected) Gold else Line, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(label, fontSize = 13.sp, color = if (selected) Bg else Ink) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatatSheet(existing: Transaksi? = null, initialType: String = JENIS_PENDAPATAN, ocrAmount: String = "", onPilihScreenshot: () -> Unit = {}, onDismiss: () -> Unit, onSimpan: (Transaksi) -> Unit) {
    val context = LocalContext.current
    var jenis by remember(existing?.id, initialType) { mutableStateOf(existing?.jenis ?: initialType) }
    var kategori by remember(existing?.id, initialType) {
        mutableStateOf(existing?.kategori ?: if (initialType == JENIS_PENDAPATAN) KATEGORI_PENDAPATAN.first() else KATEGORI_PENGELUARAN.first())
    }
    var jumlah by remember(existing?.id, ocrAmount) { mutableStateOf(existing?.jumlah?.toString() ?: ocrAmount) }
    var catatan by remember { mutableStateOf(existing?.catatan ?: "") }
    var tanggal by remember { mutableStateOf(existing?.let { LocalDate.ofEpochDay(it.tanggal) } ?: LocalDate.now()) }
    val daftar = if (jenis == JENIS_PENDAPATAN) KATEGORI_PENDAPATAN else KATEGORI_PENGELUARAN
    val nilai = jumlah.toLongOrNull() ?: 0L

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Panel,
        contentColor = Ink
    ) {
        Column(
            Modifier.fillMaxWidth().imePadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(if (existing == null) "Catat keuangan" else "Edit catatan harian", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Gold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Pendapatan", jenis == JENIS_PENDAPATAN) { jenis = JENIS_PENDAPATAN; kategori = KATEGORI_PENDAPATAN.first() }
                Chip("Pengeluaran", jenis == JENIS_PENGELUARAN) { jenis = JENIS_PENGELUARAN; kategori = KATEGORI_PENGELUARAN.first() }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                daftar.forEach { k -> Chip(k, k == kategori) { kategori = k } }
            }
            if (jenis == JENIS_PENDAPATAN) {
                TextButton(onClick = onPilihScreenshot) { Text("▧ Pilih screenshot Grab untuk dibaca otomatis", color = Gold) }
            }
            OutlinedTextField(
                value = jumlah,
                onValueChange = { jumlah = it.filter(Char::isDigit).take(12) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Jumlah") },
                prefix = { Text("Rp ") },
                supportingText = { if (nilai > 0) Text(nilai.rp()) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
                value = catatan,
                onValueChange = { catatan = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Catatan (opsional)") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
            TextButton(onClick = {
                DatePickerDialog(
                    context, { _, y, m, d -> tanggal = LocalDate.of(y, m + 1, d) },
                    tanggal.year, tanggal.monthValue - 1, tanggal.dayOfMonth
                ).show()
            }) { Text("Tanggal: " + tanggal.format(tglPendek), color = Gold) }
            Button(
                enabled = nilai > 0,
                onClick = {
                    onSimpan(Transaksi(id = existing?.id ?: 0L, tanggal = tanggal.toEpochDay(), jenis = jenis, kategori = kategori, jumlah = nilai, catatan = catatan.trim()))
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Bg)
            ) { Text(if (existing == null) "Simpan Catatan" else "Simpan Perubahan", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
        }
    }
}


@Composable
fun RingkasWidget(
    simbol: String,
    judul: String,
    nilai: String,
    warna: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Panel)
            .border(1.dp, Line, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(warna.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = simbol,
                color = warna,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = judul,
                color = Muted,
                fontSize = 10.sp,
                letterSpacing = 0.7.sp,
                maxLines = 1
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = nilai,
                color = warna,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}
