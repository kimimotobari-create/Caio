package com.example.keuangandriver

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.NumberFormat
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val Bg = Color(0xFFFAF8F5)
private val Ink = Color(0xFF2B2522)
private val Muted = Color(0xFF8C847D)
private val Line = Color(0xFFE8E3DD)
private val Accent = Color(0xFFB08968)
private val Masuk = Color(0xFF3E7C59)
private val Keluar = Color(0xFFB5533C)

private val fotoBayi = listOf(
    R.drawable.bayi_1, R.drawable.bayi_2, R.drawable.bayi_3, R.drawable.bayi_4, R.drawable.bayi_5
)

private val rupiah: NumberFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
    maximumFractionDigits = 0
}
private fun Long.rp(): String = rupiah.format(this)
private val tglPendek = DateTimeFormatter.ofPattern("d MMM yyyy", Locale("id", "ID"))
private val tglPanjang = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale("id", "ID"))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Ink, background = Bg, surface = Bg, onSurface = Ink, onBackground = Ink
                )
            ) {
                HomeScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(vm: MainViewModel = viewModel()) {
    val list by vm.transaksi.collectAsState()
    val periode by vm.periode.collectAsState()
    var showSheet by remember { mutableStateOf(false) }
    var fotoIdx by remember { mutableStateOf(LocalDate.now().dayOfYear % fotoBayi.size) }

    val pendapatan = list.filter { it.jenis == JENIS_PENDAPATAN }.sumOf { it.jumlah }
    val pengeluaran = list.filter { it.jenis == JENIS_PENGELUARAN }.sumOf { it.jumlah }
    val bersih = pendapatan - pengeluaran

    val jam = LocalTime.now().hour
    val sapa = when {
        jam < 11 -> "Selamat pagi"
        jam < 15 -> "Selamat siang"
        jam < 18 -> "Selamat sore"
        else -> "Selamat malam"
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            Box(Modifier.fillMaxWidth().background(Bg).navigationBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp)) {
                Button(
                    onClick = { showSheet = true },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Color.White)
                ) { Text("+  Catat", fontSize = 16.sp) }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 16.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(fotoBayi[fotoIdx]),
                        contentDescription = null,
                        modifier = Modifier.size(48.dp).clip(CircleShape)
                            .clickable { fotoIdx = (fotoIdx + 1) % fotoBayi.size },
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(sapa, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Ink)
                        Text(LocalDate.now().format(tglPanjang), fontSize = 12.sp, color = Muted)
                    }
                }
            }
            item {
                Spacer(Modifier.height(24.dp))
                PeriodeTabs(periode) { vm.periode.value = it }
            }
            item {
                Spacer(Modifier.height(28.dp))
                Text("Penghasilan bersih", fontSize = 13.sp, color = Muted)
                Text(
                    bersih.rp(), fontSize = 40.sp, fontWeight = FontWeight.Light,
                    color = if (bersih < 0) Keluar else Ink
                )
                Spacer(Modifier.height(20.dp))
                Row(Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("Pendapatan", fontSize = 12.sp, color = Muted)
                        Text(pendapatan.rp(), fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Masuk)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Pengeluaran", fontSize = 12.sp, color = Muted)
                        Text(pengeluaran.rp(), fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Keluar)
                    }
                }
                Spacer(Modifier.height(24.dp))
                HorizontalDivider(color = Line)
            }
            item { RincianPengeluaran(list.filter { it.jenis == JENIS_PENGELUARAN }) }
            item {
                Spacer(Modifier.height(20.dp))
                Text("RIWAYAT", fontSize = 12.sp, color = Muted, letterSpacing = 1.sp)
            }
            if (list.isEmpty()) {
                item {
                    Column(
                        Modifier.fillMaxWidth().padding(vertical = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(
                            painter = painterResource(fotoBayi[fotoIdx]),
                            contentDescription = null,
                            modifier = Modifier.size(140.dp).clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(Modifier.height(16.dp))
                        Text("Belum ada catatan", color = Muted, textAlign = TextAlign.Center)
                        Text("Semangat narik hari ini!", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                }
            }
            items(list, key = { it.id }) { t -> TransaksiRow(t, onDelete = { vm.hapus(t) }) }
        }
    }

    if (showSheet) {
        CatatSheet(onDismiss = { showSheet = false }, onSimpan = { vm.tambah(it); showSheet = false })
    }
}

@Composable
fun PeriodeTabs(selected: Periode, onSelect: (Periode) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
        Periode.values().forEach { p ->
            val aktif = p == selected
            Column(Modifier.clickable { onSelect(p) }) {
                Text(
                    p.label, fontSize = 14.sp,
                    fontWeight = if (aktif) FontWeight.Medium else FontWeight.Normal,
                    color = if (aktif) Ink else Muted
                )
                Spacer(Modifier.height(4.dp))
                Box(Modifier.height(2.dp).width(20.dp).background(if (aktif) Accent else Color.Transparent))
            }
        }
    }
}

@Composable
fun RincianPengeluaran(pengeluaran: List<Transaksi>) {
    if (pengeluaran.isEmpty()) return
    val total = pengeluaran.sumOf { it.jumlah }.coerceAtLeast(1)
    val per = pengeluaran.groupBy { it.kategori }
        .mapValues { e -> e.value.sumOf { it.jumlah } }
        .toList().sortedByDescending { it.second }
    Column(Modifier.padding(top = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PENGELUARAN", fontSize = 12.sp, color = Muted, letterSpacing = 1.sp)
        per.forEach { (k, v) ->
            val frac = (v.toFloat() / total.toFloat()).coerceIn(0.02f, 1f)
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(k, fontSize = 14.sp, color = Ink)
                    Text(v.rp(), fontSize = 14.sp, color = Muted)
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth().height(3.dp).background(Line, RoundedCornerShape(2.dp))) {
                    Box(Modifier.fillMaxWidth(frac).height(3.dp).background(Accent, RoundedCornerShape(2.dp)))
                }
            }
        }
    }
}

@Composable
fun TransaksiRow(t: Transaksi, onDelete: () -> Unit) {
    val masuk = t.jenis == JENIS_PENDAPATAN
    Column {
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.kategori, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Ink)
                Text(
                    LocalDate.ofEpochDay(t.tanggal).format(tglPendek) +
                        if (t.catatan.isNotBlank()) "  ·  ${t.catatan}" else "",
                    fontSize = 12.sp, color = Muted
                )
            }
            Text(
                (if (masuk) "+" else "−") + t.jumlah.rp(),
                fontSize = 15.sp, fontWeight = FontWeight.Medium, color = if (masuk) Masuk else Keluar
            )
            IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Hapus", tint = Muted, modifier = Modifier.size(16.dp))
            }
        }
        HorizontalDivider(color = Line)
    }
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Ink else Color.Transparent)
            .border(1.dp, if (selected) Ink else Line, RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(label, fontSize = 13.sp, color = if (selected) Color.White else Ink) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatatSheet(onDismiss: () -> Unit, onSimpan: (Transaksi) -> Unit) {
    val context = LocalContext.current
    var jenis by remember { mutableStateOf(JENIS_PENDAPATAN) }
    var kategori by remember { mutableStateOf(KATEGORI_PENDAPATAN.first()) }
    var jumlah by remember { mutableStateOf("") }
    var catatan by remember { mutableStateOf("") }
    var tanggal by remember { mutableStateOf(LocalDate.now()) }
    val daftar = if (jenis == JENIS_PENDAPATAN) KATEGORI_PENDAPATAN else KATEGORI_PENGELUARAN
    val nilai = jumlah.toLongOrNull() ?: 0L

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Bg
    ) {
        Column(
            Modifier.fillMaxWidth().imePadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Pendapatan", jenis == JENIS_PENDAPATAN) { jenis = JENIS_PENDAPATAN; kategori = KATEGORI_PENDAPATAN.first() }
                Chip("Pengeluaran", jenis == JENIS_PENGELUARAN) { jenis = JENIS_PENGELUARAN; kategori = KATEGORI_PENGELUARAN.first() }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                daftar.forEach { k -> Chip(k, k == kategori) { kategori = k } }
            }
            OutlinedTextField(
                value = jumlah,
                onValueChange = { jumlah = it.filter(Char::isDigit).take(12) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Jumlah") },
                prefix = { Text("Rp ") },
                supportingText = { if (nilai > 0) Text(nilai.rp()) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Ink, unfocusedBorderColor = Line,
                    cursorColor = Ink, focusedLabelColor = Ink
                )
            )
            OutlinedTextField(
                value = catatan,
                onValueChange = { catatan = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Catatan (opsional)") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Ink, unfocusedBorderColor = Line,
                    cursorColor = Ink, focusedLabelColor = Ink
                )
            )
            TextButton(onClick = {
                DatePickerDialog(
                    context, { _, y, m, d -> tanggal = LocalDate.of(y, m + 1, d) },
                    tanggal.year, tanggal.monthValue - 1, tanggal.dayOfMonth
                ).show()
            }) { Text("Tanggal: " + tanggal.format(tglPendek), color = Ink) }
            Button(
                enabled = nilai > 0,
                onClick = {
                    onSimpan(Transaksi(tanggal = tanggal.toEpochDay(), jenis = jenis, kategori = kategori, jumlah = nilai, catatan = catatan.trim()))
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = Color.White)
            ) { Text("Simpan", fontSize = 16.sp) }
        }
    }
}
