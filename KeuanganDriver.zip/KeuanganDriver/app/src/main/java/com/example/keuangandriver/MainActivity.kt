package com.example.keuangandriver

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

private val GrabGreen = Color(0xFF00A94F)
private val Merah = Color(0xFFD32F2F)

private val rupiah: NumberFormat = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply {
    maximumFractionDigits = 0
}
private fun Long.rp(): String = rupiah.format(this)
private val tglFmt = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale("id", "ID"))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = GrabGreen)) {
                HomeScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: MainViewModel = viewModel()) {
    val list by vm.transaksi.collectAsState()
    val periode by vm.periode.collectAsState()
    var showDialog by remember { mutableStateOf(false) }

    val pendapatan = list.filter { it.jenis == JENIS_PENDAPATAN }.sumOf { it.jumlah }
    val pengeluaran = list.filter { it.jenis == JENIS_PENGELUARAN }.sumOf { it.jumlah }
    val bersih = pendapatan - pengeluaran

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Keuangan Driver", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = GrabGreen,
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showDialog = true }, containerColor = GrabGreen, contentColor = Color.White) {
                Icon(Icons.Default.Add, contentDescription = "Tambah")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Periode.values().forEach { p ->
                        FilterChip(selected = p == periode, onClick = { vm.periode.value = p }, label = { Text(p.label) })
                    }
                }
            }
            item { RingkasanCard(pendapatan, pengeluaran, bersih) }
            item { RincianPengeluaran(list.filter { it.jenis == JENIS_PENGELUARAN }) }
            item { Text("Riwayat", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp)) }
            if (list.isEmpty()) {
                item { Text("Belum ada catatan. Tekan + untuk menambah.", color = Color.Gray) }
            }
            items(list, key = { it.id }) { t -> TransaksiRow(t, onDelete = { vm.hapus(t) }) }
            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    if (showDialog) {
        TambahDialog(onDismiss = { showDialog = false }, onSimpan = { vm.tambah(it); showDialog = false })
    }
}

@Composable
fun RingkasanCard(pendapatan: Long, pengeluaran: Long, bersih: Long) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Penghasilan Bersih", color = Color.DarkGray)
            Text(
                bersih.rp(), fontSize = 28.sp, fontWeight = FontWeight.Bold,
                color = if (bersih >= 0) GrabGreen else Merah
            )
            HorizontalDivider()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Pendapatan"); Text(pendapatan.rp(), color = GrabGreen, fontWeight = FontWeight.SemiBold)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Pengeluaran"); Text(pengeluaran.rp(), color = Merah, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun RincianPengeluaran(pengeluaran: List<Transaksi>) {
    if (pengeluaran.isEmpty()) return
    val total = pengeluaran.sumOf { it.jumlah }.coerceAtLeast(1)
    val per = pengeluaran.groupBy { it.kategori }.mapValues { e -> e.value.sumOf { it.jumlah } }
        .toList().sortedByDescending { it.second }
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Rincian Pengeluaran", fontWeight = FontWeight.Bold)
            per.forEach { (k, v) ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("$k (${v * 100 / total}%)"); Text(v.rp())
                }
            }
        }
    }
}

@Composable
fun TransaksiRow(t: Transaksi, onDelete: () -> Unit) {
    val masuk = t.jenis == JENIS_PENDAPATAN
    Card {
        Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.kategori, fontWeight = FontWeight.SemiBold)
                Text(
                    LocalDate.ofEpochDay(t.tanggal).format(tglFmt) + if (t.catatan.isNotBlank()) " • ${t.catatan}" else "",
                    fontSize = 12.sp, color = Color.Gray
                )
            }
            Text((if (masuk) "+ " else "- ") + t.jumlah.rp(), color = if (masuk) GrabGreen else Merah, fontWeight = FontWeight.Bold)
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, contentDescription = "Hapus", tint = Color.Gray) }
        }
    }
}

@Composable
fun TambahDialog(onDismiss: () -> Unit, onSimpan: (Transaksi) -> Unit) {
    val context = LocalContext.current
    var jenis by remember { mutableStateOf(JENIS_PENDAPATAN) }
    var kategori by remember { mutableStateOf(KATEGORI_PENDAPATAN.first()) }
    var jumlah by remember { mutableStateOf("") }
    var catatan by remember { mutableStateOf("") }
    var tanggal by remember { mutableStateOf(LocalDate.now()) }
    val daftarKategori = if (jenis == JENIS_PENDAPATAN) KATEGORI_PENDAPATAN else KATEGORI_PENGELUARAN

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Catatan") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = jenis == JENIS_PENDAPATAN, onClick = { jenis = JENIS_PENDAPATAN; kategori = KATEGORI_PENDAPATAN.first() }, label = { Text("Pendapatan") })
                    FilterChip(selected = jenis == JENIS_PENGELUARAN, onClick = { jenis = JENIS_PENGELUARAN; kategori = KATEGORI_PENGELUARAN.first() }, label = { Text("Pengeluaran") })
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    daftarKategori.forEach { k ->
                        FilterChip(selected = k == kategori, onClick = { kategori = k }, label = { Text(k) })
                    }
                }
                OutlinedTextField(
                    value = jumlah, onValueChange = { jumlah = it.filter(Char::isDigit) },
                    label = { Text("Jumlah (Rp)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(value = catatan, onValueChange = { catatan = it }, label = { Text("Catatan (opsional)") }, singleLine = true)
                OutlinedButton(onClick = {
                    DatePickerDialog(context, { _, y, m, d -> tanggal = LocalDate.of(y, m + 1, d) },
                        tanggal.year, tanggal.monthValue - 1, tanggal.dayOfMonth).show()
                }) { Text("Tanggal: " + tanggal.format(tglFmt)) }
            }
        },
        confirmButton = {
            Button(
                enabled = (jumlah.toLongOrNull() ?: 0L) > 0,
                onClick = { onSimpan(Transaksi(tanggal = tanggal.toEpochDay(), jenis = jenis, kategori = kategori, jumlah = jumlah.toLong(), catatan = catatan.trim())) }
            ) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
