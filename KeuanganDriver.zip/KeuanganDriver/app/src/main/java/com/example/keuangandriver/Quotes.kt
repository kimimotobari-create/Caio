package com.example.keuangandriver

data class Isi(val jenis: String, val teks: String)

val ISI_HARIAN = listOf(
    Isi("Kutipan", "Rezeki tidak akan tertukar."),
    Isi("Kutipan", "Sedikit demi sedikit, lama-lama menjadi bukit."),
    Isi("Kutipan", "Berakit-rakit ke hulu, berenang-renang ke tepian."),
    Isi("Kutipan", "Hemat pangkal kaya, rajin pangkal pandai."),
    Isi("Kutipan", "Di mana ada kemauan, di situ ada jalan."),
    Isi("Kutipan", "Pelan tapi pasti, sampai juga ke tujuan."),
    Isi("Kutipan", "Hati-hati di jalan, ada yang menunggu di rumah."),
    Isi("Kutipan", "Setiap putaran roda adalah doa untuk keluarga."),
    Isi("Kutipan", "Rezeki halal, hati tenang, keluarga senang."),
    Isi("Kutipan", "Lelah hari ini, senyum di rumah nanti."),
    Isi("Fakta unik", "Madu hampir tidak pernah basi. Madu berusia ribuan tahun dari makam Mesir kuno masih layak dimakan."),
    Isi("Fakta unik", "Gurita punya tiga jantung."),
    Isi("Fakta unik", "Bayi lahir dengan sekitar 300 tulang. Pada orang dewasa jumlahnya menyatu menjadi 206."),
    Isi("Fakta unik", "Jantung manusia berdetak sekitar 100.000 kali dalam sehari."),
    Isi("Fakta unik", "Secara botani, pisang termasuk buah beri (berry)."),
    Isi("Fakta unik", "Lebah mengepakkan sayapnya ratusan kali setiap detik."),
    Isi("Fakta unik", "Hiu sudah ada di bumi sebelum pohon pertama tumbuh."),
    Isi("Fakta unik", "Sidik jari bayi sudah terbentuk sejak masih di dalam kandungan."),
    Isi("Fakta unik", "Senyum sosial pertama bayi biasanya muncul di usia sekitar 6 sampai 8 minggu."),
    Isi("Fakta unik", "Indonesia punya sekitar 17.000 pulau dan termasuk produsen kopi terbesar di dunia.")
)
