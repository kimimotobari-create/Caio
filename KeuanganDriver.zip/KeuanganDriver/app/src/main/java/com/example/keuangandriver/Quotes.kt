package com.example.keuangandriver

data class Isi(val jenis: String, val teks: String)

// 9.000+ pesan singkat dibuat dari kombinasi nasihat praktis untuk driver,
// pengelolaan uang, keselamatan, produktivitas, dan keluarga.
private val PEMBUKA = listOf(
    "Biasakan", "Usahakan", "Ingat untuk", "Mulailah dengan", "Jangan lupa",
    "Luangkan waktu untuk", "Jadikan kebiasaan untuk", "Cobalah", "Tetap konsisten untuk", "Sempatkan"
)
private val AKSI = listOf(
    "mencatat setiap pendapatan setelah bekerja",
    "memisahkan uang modal dari uang kebutuhan rumah",
    "menyisihkan sebagian hasil untuk dana darurat",
    "memeriksa rem, ban, lampu, dan kendaraan",
    "beristirahat ketika tubuh mulai lelah",
    "mengecek kembali pengeluaran kecil setiap hari",
    "menentukan target bersih yang masuk akal",
    "menyimpan bukti pembayaran dan transaksi",
    "meluangkan waktu berkualitas bersama keluarga",
    "mengevaluasi hasil kerja sebelum tidur",
    "menyiapkan perlengkapan berkendara sebelum berangkat",
    "mengisi bahan bakar sebelum tangki terlalu kosong",
    "membandingkan hasil kerja dari hari ke hari",
    "menabung meskipun jumlahnya sedikit",
    "menghindari penggunaan ponsel saat berkendara",
    "memastikan helm terpasang dengan benar",
    "menghitung biaya operasional sebelum memakai saldo",
    "membuat daftar kebutuhan rumah yang penting",
    "mengurangi belanja yang tidak direncanakan",
    "menjaga komunikasi yang baik dengan pelanggan",
    "memilih tempat berhenti yang aman",
    "mengecek tekanan ban secara berkala",
    "mencatat biaya parkir, makan, dan minum",
    "menyisihkan dana khusus untuk servis kendaraan",
    "mengatur waktu kerja dan waktu istirahat",
    "menjaga sikap ramah dalam setiap perjalanan",
    "menyusun rencana keuangan mingguan",
    "mengecek saldo sebelum dan sesudah bekerja",
    "mengutamakan keselamatan daripada mengejar order",
    "mensyukuri hasil kerja berapa pun jumlahnya"
)
private val TUJUAN = listOf(
    "keuangan keluarga lebih mudah dikendalikan",
    "modal kerja tidak tercampur dengan uang belanja",
    "kebutuhan mendadak tidak membuat panik",
    "kendaraan tetap nyaman dan aman digunakan",
    "tubuh tetap bugar untuk perjalanan berikutnya",
    "pengeluaran kecil tidak menumpuk tanpa disadari",
    "target harian terasa lebih terarah",
    "catatan keuangan mudah diperiksa kembali",
    "keluarga tetap mendapat perhatian dan waktu",
    "hasil kerja bisa dievaluasi dengan jujur",
    "perjalanan dimulai dengan persiapan yang baik",
    "penghasilan bersih terlihat lebih jelas",
    "risiko kerusakan kendaraan bisa dikurangi",
    "kebiasaan baik terbentuk sedikit demi sedikit",
    "pikiran lebih tenang saat menjalani pekerjaan",
    "setiap rupiah memiliki tujuan yang jelas",
    "kebutuhan utama didahulukan daripada keinginan",
    "keselamatan diri dan orang lain tetap terjaga",
    "tabungan masa depan terus bertambah",
    "usaha hari ini membawa manfaat untuk keluarga",
    "waktu tidak habis untuk hal yang kurang penting",
    "kamu tidak lupa menghargai proses",
    "pengeluaran dapat dibandingkan dengan pendapatan",
    "keputusan belanja menjadi lebih bijak",
    "hari esok bisa dimulai dengan lebih siap",
    "pekerjaan terasa lebih tertata",
    "rezeki yang didapat digunakan dengan penuh syukur",
    "kamu punya gambaran kondisi keuangan sebenarnya",
    "kendaraan selalu siap saat dibutuhkan",
    "perjalanan pulang tetap menjadi prioritas"
)

val ISI_HARIAN: List<Isi> = buildList {
    val kategori = listOf("Tips keuangan", "Tips keselamatan", "Tips produktif", "Motivasi keluarga", "Kata-kata penyemangat")
    PEMBUKA.forEachIndexed { pi, pembuka ->
        AKSI.forEachIndexed { ai, aksi ->
            TUJUAN.forEachIndexed { ti, tujuan ->
                val jenis = when {
                    ai in 3..5 || ai in 14..15 || ai in 20..21 -> kategori[1]
                    ai in 0..2 || ai in 5..6 || ai in 12..13 || ai in 16..18 || ai in 22..23 || ai in 26..27 -> kategori[0]
                    ai == 8 || ai == 25 || ti in 8..9 || ti == 19 -> kategori[3]
                    ai in 9..10 || ai == 24 || ai == 28 -> kategori[2]
                    else -> kategori[4]
                }
                add(Isi(jenis, "$pembuka $aksi supaya $tujuan."))
            }
        }
    }
    add(Isi("Motivasi keluarga", "Setiap perjalanan adalah ikhtiar. Pulang dengan selamat adalah hadiah untuk keluarga."))
    add(Isi("Motivasi keluarga", "Tidak harus besar hari ini. Yang penting terus berusaha, jujur, dan tidak menyerah."))
}
