package com.example.keuangandriver

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.NumberFormat
import java.util.Locale
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class FinanceWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateAppWidget(context, manager, it) }
    }
    companion object {
        private fun rp(value: Long) = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }.format(value)
        fun updateAppWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences("widget_finance", Context.MODE_PRIVATE)
            val income = prefs.getLong("income", 0L)
            val expense = prefs.getLong("expense", 0L)
            val balance = prefs.getLong("balance", income - expense)
            val views = RemoteViews(context.packageName, R.layout.widget_finance)
            views.setTextViewText(R.id.widget_date, LocalDate.now().format(DateTimeFormatter.ofPattern("EEE, d MMM", Locale("id", "ID"))))
            views.setTextViewText(R.id.widget_balance, "Saldo ${rp(balance)}")
            views.setTextViewText(R.id.widget_income, "＋ Masuk  ${rp(income)}")
            views.setTextViewText(R.id.widget_expense, "− Keluar  ${rp(expense)}")
            val inIntent = Intent(context, MainActivity::class.java).putExtra("quick_type", JENIS_PENDAPATAN).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val outIntent = Intent(context, MainActivity::class.java).putExtra("quick_type", JENIS_PENGELUARAN).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            views.setOnClickPendingIntent(R.id.widget_income, PendingIntent.getActivity(context, 101, inIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            views.setOnClickPendingIntent(R.id.widget_expense, PendingIntent.getActivity(context, 102, outIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            val open = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            views.setOnClickPendingIntent(R.id.widget_balance, PendingIntent.getActivity(context, 103, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            manager.updateAppWidget(id, views)
        }
    }
}
