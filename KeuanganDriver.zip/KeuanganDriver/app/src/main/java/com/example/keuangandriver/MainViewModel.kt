package com.example.keuangandriver

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.combine
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

enum class Periode(val label: String) {
    HARI_INI("Hari Ini"),
    MINGGU_INI("Minggu"),
    BULAN_INI("Bulan Ini"),
    RINGKASAN("Ringkasan")
}

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()

    init { viewModelScope.launch { refreshWidget() } }

    val periode = MutableStateFlow(Periode.HARI_INI)
    val mingguOffset = MutableStateFlow(0)

    val transaksi: StateFlow<List<Transaksi>> = combine(periode, mingguOffset) { p, offset -> p to offset }
        .flatMapLatest { (p, offset) ->
            val today = LocalDate.now()
            val dari = when (p) {
                Periode.HARI_INI -> today
                Periode.MINGGU_INI -> today.with(java.time.DayOfWeek.MONDAY).plusWeeks(offset.toLong())
                Periode.BULAN_INI, Periode.RINGKASAN -> today.withDayOfMonth(1)
            }
            val sampai = when (p) {
                Periode.MINGGU_INI -> dari.plusDays(6)
                else -> today
            }
            dao.observe(dari.toEpochDay(), sampai.toEpochDay())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val grafik: StateFlow<List<Transaksi>> = dao
        .observe(LocalDate.now().minusDays(6).toEpochDay(), LocalDate.now().toEpochDay())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private suspend fun refreshWidget() {
        val all = dao.all()
        val income = all.filter { it.jenis == JENIS_PENDAPATAN }.sumOf { it.jumlah }
        val expense = all.filter { it.jenis == JENIS_PENGELUARAN }.sumOf { it.jumlah }
        val prefs = getApplication<Application>().getSharedPreferences("widget_finance", Context.MODE_PRIVATE)
        prefs.edit().putLong("income", income).putLong("expense", expense).putLong("balance", income - expense).apply()
        val manager = AppWidgetManager.getInstance(getApplication())
        val ids = manager.getAppWidgetIds(ComponentName(getApplication(), FinanceWidgetProvider::class.java))
        ids.forEach { FinanceWidgetProvider.updateAppWidget(getApplication(), manager, it) }
    }
    fun tambah(t: Transaksi) = viewModelScope.launch { dao.insert(t); refreshWidget() }
    fun edit(t: Transaksi) = viewModelScope.launch { dao.update(t); refreshWidget() }
    fun hapus(t: Transaksi) = viewModelScope.launch { dao.delete(t); refreshWidget() }
}
