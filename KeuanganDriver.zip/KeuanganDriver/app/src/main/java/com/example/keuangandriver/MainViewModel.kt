package com.example.keuangandriver

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

enum class Periode(val label: String) {
    HARI_INI("Hari Ini"),
    MINGGU_INI("7 Hari"),
    BULAN_INI("Bulan Ini")
}

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()

    val periode = MutableStateFlow(Periode.HARI_INI)

    val transaksi: StateFlow<List<Transaksi>> = periode
        .flatMapLatest { p ->
            val today = LocalDate.now()
            val dari = when (p) {
                Periode.HARI_INI -> today
                Periode.MINGGU_INI -> today.minusDays(6)
                Periode.BULAN_INI -> today.withDayOfMonth(1)
            }
            dao.observe(dari.toEpochDay(), today.toEpochDay())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val grafik: StateFlow<List<Transaksi>> = dao
        .observe(LocalDate.now().minusDays(6).toEpochDay(), LocalDate.now().toEpochDay())
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun tambah(t: Transaksi) = viewModelScope.launch { dao.insert(t) }
    fun edit(t: Transaksi) = viewModelScope.launch { dao.update(t) }
    fun hapus(t: Transaksi) = viewModelScope.launch { dao.delete(t) }
}
