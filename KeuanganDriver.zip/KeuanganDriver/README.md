# Sangu Kapiii

Aplikasi Android (Kotlin + Jetpack Compose + Room) untuk mencatat pendapatan dan pengeluaran driver ojol.

## Fitur
- Pendapatan: Grab Bike dan Gojek
- Pengeluaran: BBM, parkir, tol, makan, servis, cicilan, pulsa, dll.
- Ringkasan penghasilan bersih per hari, 7 hari, dan bulan ini
- Grafik pendapatan vs pengeluaran 7 hari terakhir
- Rincian pengeluaran per kategori
- Kutipan dan fakta unik acak di bagian atas (ketuk ikon gift untuk ganti)
- Data tersimpan lokal di HP

Catatan: data diinput manual, tidak terhubung ke aplikasi Grab atau Gojek.
