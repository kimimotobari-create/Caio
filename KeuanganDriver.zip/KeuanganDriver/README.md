# Sangu Kapiii – Keuangan Driver

Proyek Android Kotlin + Jetpack Compose. Tampilan keluarga dan video landscape tetap dipertahankan dengan tema gelap biru minimalis.

## Fitur tambahan versi ini
- Widget home screen Android: menampilkan saldo keseluruhan, total masuk dan keluar. Tombol Masuk (+) dan Keluar (-) membuka form catatan yang sesuai.
- Setiap tab periode menampilkan rentang tanggal yang jelas: Hari Ini, Minggu, Bulan Ini, dan Ringkasan.
- Accent aplikasi menggunakan biru minimalis pada tombol, tab aktif, grafik, dan elemen interaktif.
- Tab Minggu memiliki navigasi minggu sebelumnya/berikutnya (periode Senin–Minggu), dan tanggal rentangnya ikut berubah.
- Tab Ringkasan untuk total pemasukan, pengeluaran, saldo bersih dan jumlah transaksi bulan berjalan.
- OCR screenshot: pilih gambar/screenshot dari galeri, ML Kit membaca teks dan mengisi perkiraan nominal terbesar ke form pendapatan. Periksa nominal sebelum menyimpan karena OCR dapat salah membaca angka.
- Database Room dan video/foto keluarga dari proyek sebelumnya tetap disertakan.

## Cara memasang widget
1. Build dan instal APK.
2. Tekan lama area kosong di Home Screen Android.
3. Pilih Widget → Sangu Kapiii / Keuangan Driver.
4. Tarik widget ke layar utama.

## Build
Buka folder proyek ini di Android Studio, tunggu Gradle Sync, lalu Build APK.

Catatan: source code telah diperbarui. APK belum dibangun atau diuji pada perangkat; jalankan Gradle Sync dan Build APK di Android Studio untuk verifikasi kompilasi. Widget memakai ringkasan seluruh transaksi tersimpan. OCR membaca screenshot yang dipilih pengguna; tidak mengambil screenshot otomatis dari aplikasi Grab.
