# Sangu Kapiii — Keuangan Driver

Aplikasi Android Kotlin + Jetpack Compose untuk mencatat pendapatan dan pengeluaran driver dengan nuansa keluarga.

## Pembaruan versi ini
- Video MP4 yang diberikan pengguna dipakai sebagai background landscape pada header, diputar berulang tanpa suara.
- Ringkasan widget Pendapatan (+), Pengeluaran (-), dan Saldo Bersih.
- Tombol widget + dan - langsung membuka formulir dengan jenis transaksi terkait.
- Grafik pendapatan dan pengeluaran 7 hari terakhir.
- Edit dan hapus catatan transaksi harian.
- Pilihan periode Hari Ini, 7 Hari, dan Bulan Ini.
- Koleksi lebih dari 9.000 kata-kata/tips/motivasi yang ditampilkan bergantian.
- Data transaksi disimpan lokal memakai Room database.

## Membuka proyek
1. Ekstrak ZIP.
2. Buka folder `KeuanganDriver` di Android Studio.
3. Tunggu Gradle Sync selesai.
4. Jalankan di emulator atau perangkat Android.

## Catatan
- Video disimpan di `app/src/main/res/raw/bg_landscape.mp4`.
- Aplikasi tidak mengambil data otomatis dari akun Grab. Transaksi dicatat manual.
- Build APK: Android Studio → Build → Build Bundle(s) / APK(s) → Build APK(s).
