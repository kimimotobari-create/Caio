# Sangu Kapiii – Keuangan Driver

Proyek Android Kotlin + Jetpack Compose. Tampilan keluarga, video landscape, tema gelap-cokelat dan emas tetap dipertahankan.

## Fitur tambahan versi ini
- Widget home screen Android: menampilkan saldo keseluruhan, total masuk dan keluar. Tombol Masuk (+) dan Keluar (-) membuka form catatan yang sesuai.
- Tab Minggu dengan navigasi minggu sebelumnya/berikutnya (periode Senin–Minggu).
- Tab Ringkasan untuk total pemasukan, pengeluaran, saldo bersih dan jumlah transaksi bulan berjalan.
- OCR screenshot: pilih gambar/screenshot dari galeri, ML Kit membaca teks dan mengisi perkiraan nominal terbesar ke form pendapatan. Periksa nominal sebelum menyimpan karena OCR dapat salah membaca angka.
- Database Room dan video/foto keluarga dari proyek sebelumnya tetap disertakan.

## Cara memasang widget
1. Build dan instal APK.
2. Tekan lama area kosong di Home Screen Android.
3. Pilih Widget → Sangu Kapiii / Keuangan Driver.
4. Tarik widget ke layar utama.

## Build
Buka folder proyek ini di Android Studio, tunggu Gradle Sync, lalu Build APK.

Catatan: source code telah diperbarui. Build APK perlu dijalankan di Android Studio/GitHub Actions untuk verifikasi kompilasi dan pengujian perangkat. Widget memakai ringkasan seluruh transaksi tersimpan. OCR membaca screenshot yang dipilih pengguna; tidak mengambil screenshot otomatis dari aplikasi Grab.
