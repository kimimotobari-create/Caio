# Keuangan Driver

Aplikasi Android (Kotlin + Jetpack Compose + Room) untuk mencatat pendapatan dan pengeluaran driver ojol/taksi online.

## Fitur
- Catat pendapatan: GrabCar, GrabBike, GrabFood, GrabExpress, tip, bonus/insentif
- Catat pengeluaran: BBM, parkir, tol, makan, servis, cicilan, pulsa, dll.
- Ringkasan penghasilan bersih (pendapatan - pengeluaran) per hari, 7 hari, dan bulan ini
- Rincian pengeluaran per kategori dengan persentase
- Riwayat transaksi, bisa dihapus
- Data tersimpan lokal di HP (tanpa internet)

## Cara build
1. Buka folder ini di Android Studio (Koala atau lebih baru, JDK 17).
2. Tunggu Gradle sync selesai.
3. Jalankan di emulator/HP (Android 8.0+), atau Build > Build APK(s).

Catatan: aplikasi ini tidak terhubung ke aplikasi Grab; semua data diinput manual.
