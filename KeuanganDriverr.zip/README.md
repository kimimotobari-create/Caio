# Pemutar Video Kavi — Android

Aplikasi Android bertema biru minimalis.

## Fitur
- Memutar video YouTube melalui YouTube embedded player resmi.
- Memilih dan memutar video lokal dari perangkat dengan Media3 ExoPlayer.
- Mengunduh file video dari URL HTTP/HTTPS langsung menggunakan Android DownloadManager.
- Notifikasi progres/selesai download dari sistem Android dan penyimpanan ke folder Download.

## Batasan penting
Fitur download hanya untuk URL file video langsung yang memang mengizinkan pengunduhan (misalnya MP4). Menempelkan URL halaman YouTube tidak akan mengunduh video YouTube. Untuk YouTube, gunakan fitur download resmi YouTube jika tersedia, atau unduh video yang Anda miliki hak dan izinnya. Aplikasi tidak mengekstrak stream atau melewati pembatasan YouTube.

## Membuat APK
1. Ekstrak ZIP ini.
2. Buka folder proyek melalui Android Studio.
3. Gunakan JDK 17 dan Android SDK 35, lalu tunggu Gradle Sync.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

Dependensi Gradle diunduh saat sinkronisasi pertama, sehingga perlu koneksi internet.
