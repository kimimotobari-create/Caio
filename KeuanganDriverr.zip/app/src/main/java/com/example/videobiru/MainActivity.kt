package com.example.videobiru

import android.net.Uri
import android.app.DownloadManager
import android.content.Context
import android.os.Environment
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : AppCompatActivity() {
    private val blue = 0xFF1769E0.toInt()
    private val navy = 0xFF071A36.toInt()
    private lateinit var content: LinearLayout
    private var player: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var webView: WebView? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { content.removeAllViews(); playLocal(uri) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFFF4F7FC.toInt()) }
        root.addView(TextView(this).apply {
            text = "▶  Pemutar Video Kavi"; textSize = 23f; setTextColor(-1); setPadding(20, 22, 16, 22)
            setBackgroundColor(navy); typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18) }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER; setBackgroundColor(-1) }
        nav.addView(navButton("Beranda") { showHome() }, LinearLayout.LayoutParams(0, 58, 1f))
        nav.addView(navButton("Video lokal") { pickVideo.launch(arrayOf("video/*")) }, LinearLayout.LayoutParams(0, 58, 1f))
        nav.addView(navButton("Tentang") { showAbout() }, LinearLayout.LayoutParams(0, 58, 1f))
        root.addView(nav)
        setContentView(root)
        showHome()
    }

    private fun navButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(blue); setBackgroundColor(-1); setOnClickListener { action() }
    }

    private fun title(value: String) = TextView(this).apply {
        text = value; textSize = 20f; setTextColor(navy); typeface = android.graphics.Typeface.DEFAULT_BOLD; setPadding(0, 8, 0, 10)
    }

    private fun showHome() {
        releasePlayer(); webView?.destroy(); webView = null; content.removeAllViews()
        content.addView(title("Pemutar Video Kavi"))
        content.addView(TextView(this).apply {
            text = "Tempel tautan YouTube untuk menonton melalui pemutar resmi, atau pilih video dari perangkat."
            textSize = 14f; setTextColor(0xFF52627A.toInt()); setPadding(0, 0, 0, 16)
        })
        val link = EditText(this).apply { hint = "https://www.youtube.com/watch?v=..."; singleLine = true; textSize = 14f; setPadding(12, 12, 12, 12); setBackgroundColor(-1) }
        content.addView(link, LinearLayout.LayoutParams(-1, 54))
        content.addView(Button(this).apply {
            text = "Tonton YouTube"; isAllCaps = false; setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue)); setTextColor(-1)
            setOnClickListener { openYouTube(link.text.toString().trim()) }
        }, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 12 })
        content.addView(Button(this).apply {
            text = "Pilih video dari HP"; isAllCaps = false; setOnClickListener { pickVideo.launch(arrayOf("video/*")) }
        }, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 8 })

        content.addView(title("Download video berizin").apply { setPadding(0, 22, 0, 8) })
        content.addView(TextView(this).apply {
            text = "Masukkan URL file video langsung (misalnya MP4) yang mengizinkan pengunduhan. Tautan halaman YouTube tidak bisa diunduh melalui fitur ini."
            textSize = 13f; setTextColor(0xFF52627A.toInt()); setPadding(0, 0, 0, 10)
        })
        val downloadUrl = EditText(this).apply {
            hint = "https://contoh.com/video.mp4"; singleLine = true; textSize = 14f
            setPadding(12, 12, 12, 12); setBackgroundColor(-1)
        }
        content.addView(downloadUrl, LinearLayout.LayoutParams(-1, 54))
        content.addView(Button(this).apply {
            text = "Download MP4"; isAllCaps = false
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue)); setTextColor(-1)
            setOnClickListener { downloadDirectVideo(downloadUrl.text.toString().trim()) }
        }, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 10 })
        content.addView(TextView(this).apply {
            text = "Untuk video YouTube, gunakan opsi download resmi YouTube jika tersedia. Unduh hanya video milik Anda atau yang Anda punya izin untuk simpan."
            textSize = 12f; setTextColor(0xFF64748B.toInt()); setPadding(2, 16, 2, 0)
        })
    }

    private fun downloadDirectVideo(raw: String) {
        try {
            val uri = Uri.parse(raw)
            val scheme = uri.scheme?.lowercase()
            if (scheme != "https" && scheme != "http") {
                Toast.makeText(this, "Gunakan URL video HTTP atau HTTPS", Toast.LENGTH_LONG).show()
                return
            }
            val pathName = uri.lastPathSegment?.takeIf { it.isNotBlank() } ?: "video.mp4"
            val fileName = pathName.substringBefore("?").let {
                if (it.contains(".")) it else "$it.mp4"
            }.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val request = DownloadManager.Request(uri)
                .setTitle(fileName)
                .setDescription("Mengunduh video ke folder Download")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                .setAllowedOverMetered(true)
                .setAllowedOverRoaming(false)
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(this, "Download dimulai. Cek notifikasi atau folder Download.", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "URL tidak valid atau tidak dapat diunduh", Toast.LENGTH_LONG).show()
        }
    }

    private fun extractYouTubeId(raw: String): String? {
        return try {
            val uri = Uri.parse(raw)
            val host = uri.host
            val id = when {
                host?.contains("youtu.be") == true -> uri.lastPathSegment
                host?.contains("youtube.com") == true -> uri.getQueryParameter("v")
                    ?: if (uri.pathSegments.size >= 2 && (uri.pathSegments[0] == "embed" || uri.pathSegments[0] == "shorts" || uri.pathSegments[0] == "live")) uri.pathSegments[1] else null
                else -> null
            }
            id?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{11}")) }
        } catch (_: Exception) { null }
    }

    private fun openYouTube(raw: String) {
        val id = extractYouTubeId(raw)
        if (id == null) { Toast.makeText(this, "Tautan YouTube tidak valid", Toast.LENGTH_SHORT).show(); return }
        releasePlayer(); content.removeAllViews(); content.addView(title("Pemutar YouTube"))
        val web = WebView(this)
        web.settings.javaScriptEnabled = true; web.settings.domStorageEnabled = true
        web.webChromeClient = WebChromeClient(); web.webViewClient = WebViewClient()
        val html = "<!doctype html><html><body style='margin:0;background:#071A36'><iframe width='100%' height='260' src='https://www.youtube-nocookie.com/embed/$id?playsinline=1' title='YouTube video player' frameborder='0' allow='accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share' allowfullscreen></iframe></body></html>"
        web.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null)
        webView = web
        content.addView(web, LinearLayout.LayoutParams(-1, 250))
        content.addView(Button(this).apply { text = "Kembali"; setOnClickListener { showHome() } })
    }

    private fun playLocal(uri: Uri) {
        releasePlayer()
        val view = PlayerView(this); playerView = view
        val exo = ExoPlayer.Builder(this).build(); player = exo; view.player = exo
        exo.setMediaItem(MediaItem.fromUri(uri)); exo.prepare(); exo.playWhenReady = true
        content.addView(view, LinearLayout.LayoutParams(-1, 240))
        content.addView(TextView(this).apply { text = "Video lokal diputar dari perangkat."; setTextColor(navy); setPadding(0, 12, 0, 0) })
    }

    private fun showAbout() {
        releasePlayer(); content.removeAllViews(); content.addView(title("Tentang VideoBiru"))
        content.addView(TextView(this).apply {
            text = "VideoBiru adalah pemutar video sederhana dengan tema biru minimalis. Mendukung pemutaran YouTube melalui embed resmi dan video lokal dari perangkat. Tidak ada pengunduh YouTube pihak ketiga."
            textSize = 15f; setTextColor(navy)
        })
    }

    private fun releasePlayer() { player?.release(); player = null; playerView?.player = null; playerView = null }
    override fun onDestroy() { releasePlayer(); webView?.destroy(); super.onDestroy() }
}
